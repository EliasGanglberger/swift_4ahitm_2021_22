class Model {
    var numberToGuess = 0
    var counter = 0
    
    func compare(guess guessedNumber:Int!) -> Int! {
        var result = 0
        
        if guessedNumber < numberToGuess {
            result = -1
        } else if guessedNumber > numberToGuess {
            result = 1
        }
        
        return result
    }
    
    func isValid(guess guessNumber:String?) -> Bool {
        var result = false
        if let str = guessNumber {
            let guess = Int(str)
            if let number = guess {
                if number > 0 && number < 100 {
                    result = true
                }
            }
        }
        
        return result
    }
    
    func compare(guessedString:String!) -> Int {
        return compare(guess: Int.init(guessedString))
    }
}
