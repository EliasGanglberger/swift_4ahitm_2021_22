import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputTextfield: UITextField!
    @IBOutlet weak var outputLable: UILabel!
    var model = Model()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        model.numberToGuess = Int.random(in: 1..<100)
    }
        
    @IBOutlet weak var guessButton: UIButton!
    
    @IBAction func editChanged(_ sender: String) {
        guessButton.isEnabled = model.isValid(guess: sender)
    }
    
    @IBAction func onchangeTextfield(_ sender: UITextField) {
        print("text is now \(sender)")
    }
    
    @IBAction func guessButton(_ sender: UIButton) {
        let num = model.compare(guessedString: inputTextfield.text)
        print(model.numberToGuess)
        
        let text: String?
        switch num {
        case -1:
            text = "Too low!"
        case 1:
            text = "Too high!"
        default:
            text = "Correct gues"
        }
        outputLable.text = text
        model.counter += 1
    }
    
}

